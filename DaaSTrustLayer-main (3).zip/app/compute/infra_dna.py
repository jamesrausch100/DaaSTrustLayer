"""
Market2Agent — Infrastructure DNA Fingerprinting
The digital equivalent of reading a building's architectural plans.

Every HTTP response leaks information about the infrastructure behind it.
We read the Server header, CDN headers, WAF signatures, tech-stack markers,
and response timing to build a unique "Infrastructure DNA" fingerprint.

Why this matters for trust:
  - Enterprise sites run on Cloudflare/Akamai/AWS CloudFront with WAF → professionalism signal
  - Phishing sites run on bare nginx/Apache on cheap VPS → risk signal
  - Sites with CDN + WAF + fast response = investment in infrastructure
  - The COMBINATION is the fingerprint: "Cloudflare CDN + nginx origin + React frontend"
    is different from "No CDN + Apache + WordPress"

The fingerprint hash is deterministic: same infrastructure → same hash.
This lets us detect infrastructure changes over time (TrustChain delta).

Inspired by:
  - ASML precision standards (measure everything, assume nothing)
  - Intel HVM process control (infrastructure IS the product)
"""
import hashlib
import re
import time
from typing import Dict, Any, List, Optional, Tuple

import httpx
import structlog

logger = structlog.get_logger()


# ── CDN Detection Signatures ─────────────────────

CDN_SIGNATURES: Dict[str, List[Tuple[str, str]]] = {
    # CDN name → [(header_name, value_pattern), ...]
    "cloudflare": [
        ("server", "cloudflare"),
        ("cf-ray", ""),           # Presence of header alone is sufficient
        ("cf-cache-status", ""),
    ],
    "akamai": [
        ("x-akamai-transformed", ""),
        ("x-cache", ".*akamai.*"),
        ("server", ".*akamaighost.*"),
    ],
    "aws_cloudfront": [
        ("x-amz-cf-id", ""),
        ("x-amz-cf-pop", ""),
        ("via", ".*cloudfront.*"),
        ("server", ".*cloudfront.*"),
    ],
    "fastly": [
        ("x-served-by", ".*cache.*"),
        ("x-fastly-request-id", ""),
        ("via", ".*varnish.*"),
        ("x-cache", ".*fastly.*"),
    ],
    "google_cloud_cdn": [
        ("via", ".*google.*"),
        ("server", ".*gws.*"),
        ("x-goog-.*", ""),
    ],
    "azure_cdn": [
        ("x-msedge-ref", ""),
        ("x-azure-ref", ""),
        ("server", ".*ecacc.*"),
    ],
    "vercel": [
        ("x-vercel-id", ""),
        ("x-vercel-cache", ""),
        ("server", "vercel"),
    ],
    "netlify": [
        ("x-nf-request-id", ""),
        ("server", "netlify"),
    ],
    "bunny_cdn": [
        ("cdn-pullzone", ""),
        ("cdn-uid", ""),
        ("server", ".*bunny.*"),
    ],
    "sucuri": [
        ("x-sucuri-id", ""),
        ("server", ".*sucuri.*"),
    ],
    "incapsula": [
        ("x-iinfo", ""),
        ("x-cdn", ".*incapsula.*"),
    ],
    "stackpath": [
        ("x-sp-.*", ""),
        ("x-hw", ""),
    ],
}


# ── WAF Detection Signatures ─────────────────────

WAF_SIGNATURES: Dict[str, List[Tuple[str, str]]] = {
    "cloudflare_waf": [
        ("cf-ray", ""),
        ("server", "cloudflare"),
    ],
    "aws_waf": [
        ("x-amzn-waf-.*", ""),
        ("x-amzn-requestid", ""),
    ],
    "akamai_kona": [
        ("server", ".*akamaighost.*"),
        ("x-akamai-transformed", ""),
    ],
    "imperva_incapsula": [
        ("x-iinfo", ""),
        ("x-cdn", ".*incapsula.*"),
    ],
    "sucuri_waf": [
        ("x-sucuri-id", ""),
        ("x-sucuri-cache", ""),
    ],
    "f5_big_ip": [
        ("server", ".*big-ip.*"),
        ("x-wa-info", ""),
    ],
    "modsecurity": [
        ("server", ".*mod_security.*"),
    ],
    "wordfence": [
        ("x-powered-by", ".*wordfence.*"),
    ],
}


# ── Tech Stack Detection ─────────────────────────

TECH_STACK_HEADERS: Dict[str, List[Tuple[str, str]]] = {
    # Tech name → [(header_name, value_pattern), ...]
    "nginx": [("server", "nginx")],
    "apache": [("server", "apache")],
    "iis": [("server", ".*microsoft-iis.*")],
    "litespeed": [("server", "litespeed")],
    "caddy": [("server", "caddy")],
    "envoy": [("server", "envoy")],
    "openresty": [("server", "openresty")],

    # Application frameworks
    "express": [("x-powered-by", "express")],
    "asp_net": [("x-powered-by", "asp.net"), ("x-aspnet-version", "")],
    "php": [("x-powered-by", "php")],
    "django": [("x-frame-options", "deny"), ("server", ".*wsgiserver.*")],
    "rails": [("x-request-id", ""), ("x-runtime", "")],
    "next_js": [("x-nextjs-.*", ""), ("x-powered-by", "next.js")],
    "nuxt": [("x-powered-by", "nuxt")],

    # CMS
    "wordpress": [("x-powered-by", ".*wordpress.*"), ("link", ".*wp-json.*")],
    "shopify": [("x-shopify-stage", ""), ("x-shopid", "")],
    "squarespace": [("server", "squarespace"), ("x-served-by", ".*squarespace.*")],
    "wix": [("x-wix-.*", ""), ("server", "pepyaka")],

    # Caching
    "varnish": [("via", ".*varnish.*"), ("x-varnish", "")],
    "redis_cache": [("x-redis-.*", "")],
}


# ── Server Fingerprint Normalizer ─────────────────

def _normalize_server(raw_server: str) -> str:
    """
    Extract the clean server identity from a Server header.

    'nginx/1.25.3 (Ubuntu)' → 'nginx'
    'Apache/2.4.57 (Debian)' → 'apache'
    'cloudflare' → 'cloudflare'
    'Microsoft-IIS/10.0' → 'microsoft-iis'
    """
    if not raw_server:
        return ""
    s = raw_server.lower().strip()
    # Extract base name before version
    match = re.match(r'^([a-z_-]+)', s)
    return match.group(1) if match else s[:32]


def _extract_server_version(raw_server: str) -> str:
    """Extract version from Server header if present."""
    if not raw_server:
        return ""
    match = re.search(r'/(\d+[\.\d]*)', raw_server)
    return match.group(1) if match else ""


# ── Header Pattern Matcher ────────────────────────

def _match_signatures(
    headers: Dict[str, str],
    signatures: Dict[str, List[Tuple[str, str]]],
) -> List[str]:
    """
    Match response headers against a signature database.
    Returns list of matched signature names.

    Supports:
      - Exact header name match
      - Wildcard header name match (x-vercel-*)
      - Value regex match
      - Presence-only match (empty value pattern)
    """
    matches = []

    for sig_name, patterns in signatures.items():
        matched = False
        for header_pattern, value_pattern in patterns:
            # Check if this pattern matches any response header
            for h_name, h_value in headers.items():
                # Header name match (supports wildcards via regex)
                name_match = False
                if ".*" in header_pattern or "*" in header_pattern:
                    regex_pattern = header_pattern.replace("*", ".*")
                    if re.match(regex_pattern, h_name, re.IGNORECASE):
                        name_match = True
                elif h_name == header_pattern:
                    name_match = True

                if not name_match:
                    continue

                # Value match
                if not value_pattern:
                    # Presence-only check
                    matched = True
                    break
                elif re.search(value_pattern, h_value, re.IGNORECASE):
                    matched = True
                    break

            if matched:
                break

        if matched:
            matches.append(sig_name)

    return matches


# ── Response Time Calibration ─────────────────────

async def _measure_response_time(
    domain: str,
    client: httpx.AsyncClient,
    samples: int = 3,
) -> Tuple[float, float, float]:
    """
    Measure response time with multiple samples.
    Returns (median_ms, min_ms, max_ms).

    This is the "auto-calibration" — we don't rely on a single measurement.
    Three samples catch transient latency spikes.
    """
    times = []
    for _ in range(samples):
        t0 = time.time()
        try:
            resp = await client.head(
                f"https://{domain}",
                timeout=5.0,
                follow_redirects=True,
            )
            elapsed = (time.time() - t0) * 1000
            if resp.status_code < 500:
                times.append(round(elapsed, 2))
        except Exception:
            pass
        # Tiny pause between samples to not look like an attack
        if samples > 1:
            import asyncio
            await asyncio.sleep(0.1)

    if not times:
        return 0.0, 0.0, 0.0

    times.sort()
    median_idx = len(times) // 2
    return times[median_idx], min(times), max(times)


# ── Fingerprint Hash ──────────────────────────────

def compute_fingerprint_hash(
    server: str,
    cdn: str,
    waf: str,
    tech_stack: List[str],
) -> str:
    """
    Deterministic hash of the infrastructure profile.
    Same infra → same hash. Infra changes → hash changes → TrustChain delta.
    """
    content = "|".join([
        server.lower(),
        cdn.lower(),
        waf.lower(),
        ",".join(sorted(t.lower() for t in tech_stack)),
    ])
    return hashlib.sha256(content.encode()).hexdigest()[:24]


# ── Main Collector ────────────────────────────────

async def collect_infra_dna(
    domain: str,
    client: httpx.AsyncClient,
    ssl_cert_type: str = "",
) -> Dict[str, Any]:
    """
    Infrastructure DNA Fingerprinting.

    Makes a single GET request and extracts:
      - Server identity (nginx, Apache, Cloudflare, etc.)
      - CDN provider (Cloudflare, Akamai, CloudFront, Fastly, etc.)
      - WAF presence and type
      - Tech stack (framework, CMS, caching layers)
      - Response timing (3-sample median)
      - Fingerprint hash (deterministic)

    Returns a flat dict of signals ready for RawSignals.
    """
    signals = {
        # Server
        "infra_server": "",
        "infra_server_version": "",
        "infra_server_raw": "",

        # CDN
        "infra_cdn": "",
        "infra_has_cdn": False,

        # WAF
        "infra_waf": "",
        "infra_has_waf": False,

        # Tech stack
        "infra_tech_stack": [],

        # Response time
        "infra_response_time_ms": 0.0,
        "infra_response_time_min_ms": 0.0,
        "infra_response_time_max_ms": 0.0,
        "infra_response_time_variance_ms": 0.0,

        # Fingerprint
        "infra_fingerprint_hash": "",

        # Org name (from headers if available)
        "infra_org_name": "",

        # Raw header count (complexity signal)
        "infra_header_count": 0,

        # Hosting indicators
        "infra_is_shared_hosting": False,
        "infra_is_saas_platform": False,
    }

    try:
        # Primary request
        t0 = time.time()
        resp = await client.get(
            f"https://{domain}",
            follow_redirects=True,
            timeout=10.0,
        )
        primary_time = round((time.time() - t0) * 1000, 2)

        headers = {k.lower(): v.lower() for k, v in resp.headers.items()}
        signals["infra_header_count"] = len(resp.headers)

        # ── Server Identity ───────────────────────
        raw_server = resp.headers.get("server", "")
        signals["infra_server_raw"] = raw_server
        signals["infra_server"] = _normalize_server(raw_server)
        signals["infra_server_version"] = _extract_server_version(raw_server)

        # ── CDN Detection ─────────────────────────
        cdn_matches = _match_signatures(headers, CDN_SIGNATURES)
        if cdn_matches:
            signals["infra_cdn"] = cdn_matches[0]  # Primary CDN
            signals["infra_has_cdn"] = True

        # ── WAF Detection ─────────────────────────
        waf_matches = _match_signatures(headers, WAF_SIGNATURES)
        if waf_matches:
            signals["infra_waf"] = waf_matches[0]
            signals["infra_has_waf"] = True

        # ── Tech Stack ────────────────────────────
        tech_matches = _match_signatures(headers, TECH_STACK_HEADERS)
        signals["infra_tech_stack"] = tech_matches

        # ── SaaS / Shared Hosting Detection ───────
        saas_platforms = {"shopify", "squarespace", "wix", "vercel", "netlify"}
        if any(t in saas_platforms for t in tech_matches + cdn_matches):
            signals["infra_is_saas_platform"] = True

        shared_hosting_indicators = [
            "x-host" in headers,
            "x-node" in headers,
            headers.get("server", "").startswith("apache") and not signals["infra_has_cdn"],
        ]
        if sum(shared_hosting_indicators) >= 2:
            signals["infra_is_shared_hosting"] = True

        # ── Org name extraction from headers ──────
        # Some CDNs/platforms leak org info
        for h_key in ["x-organization", "x-org", "x-client", "x-account"]:
            if h_key in headers:
                org = headers[h_key].strip()
                if len(org) > 2 and len(org) < 100:
                    signals["infra_org_name"] = org
                    break

        # ── Response Time Calibration ─────────────
        # Use the primary request time as first sample, then measure 2 more
        median, rmin, rmax = await _measure_response_time(domain, client, samples=2)
        if median > 0:
            # Combine with primary request for 3 total samples
            all_times = sorted([primary_time, median, rmin if rmin > 0 else median])
            signals["infra_response_time_ms"] = all_times[len(all_times) // 2]
            signals["infra_response_time_min_ms"] = min(all_times)
            signals["infra_response_time_max_ms"] = max(all_times)
            signals["infra_response_time_variance_ms"] = round(
                max(all_times) - min(all_times), 2
            )
        else:
            signals["infra_response_time_ms"] = primary_time

        # ── Fingerprint ──────────────────────────
        signals["infra_fingerprint_hash"] = compute_fingerprint_hash(
            server=signals["infra_server"],
            cdn=signals["infra_cdn"],
            waf=signals["infra_waf"],
            tech_stack=signals["infra_tech_stack"],
        )

    except Exception as e:
        logger.debug("infra_dna_failed", domain=domain, error=str(e))

    return signals


# ── Merge Helper ──────────────────────────────────

def merge_http_and_infra(
    http_signals: Dict[str, Any],
    infra_signals: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Merge standard HTTP header signals with Infrastructure DNA signals.
    Infra signals are prefixed with 'infra_' so there's no collision.
    """
    merged = {**http_signals, **infra_signals}
    return merged
