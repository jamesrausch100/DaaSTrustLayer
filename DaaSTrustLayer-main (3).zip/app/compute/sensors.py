"""
Market2Agent — Sensor Network v4.1 (DAG-Powered)
Every collector is a sensor. Every result is a block on the chain.
Now with dependency-ordered execution via the DAG pipeline.

The DAG pipeline replaces flat asyncio.gather(*) with tiered execution:
    Tier 0: DNS, WHOIS, Tranco, crt.sh (no dependencies)
    Tier 1: HTTP + InfraDNA, VirusTotal (gated by Tier 0)
    Tier 2: Knowledge Graph, Web Presence, Social (enriched by Tier 0+1)

This module provides observe_entity() — the single entry point for scoring.
"""
import time
from typing import Dict, Any

import structlog

from app.trust.engine_v3 import RawSignals

logger = structlog.get_logger()


async def observe_entity(target: str) -> RawSignals:
    """
    Run all sensors on an entity using the DAG enrichment pipeline.
    Records every observation to the TrustChain.
    Returns a RawSignals object for scoring.

    This is v4.1: dependency-ordered collection with Infrastructure DNA.
    """
    from app.compute.dag import run_dag
    from app.chain.trustchain import record_observation, Sensor
    from app.trust.engine_v3 import compute_score

    start = time.time()

    # Run the full DAG pipeline
    raw, dag_ctx = await run_dag(target)

    # Record the score itself as a chain block
    score_result = compute_score(raw)

    entity_id = dag_ctx.domain or target.lower().strip()

    try:
        record_observation(
            entity_id=entity_id,
            sensor=Sensor.SCORE.value,
            signals={
                "score": score_result.score,
                "grade": score_result.grade.value,
                "recommendation": score_result.recommendation.value,
                "confidence": score_result.confidence,
                "ea": score_result.existence_age,
                "si": score_result.security_integrity,
                "rs": score_result.reputation_scale,
                "om": score_result.operational_maturity,
                "cap": score_result.cap_applied,
                "infra_fingerprint": score_result.infra_dna.get("fingerprint_hash", ""),
                "dag_tiers": [
                    len(raw.dag_metadata.get("tier_0_sensors", [])),
                    len(raw.dag_metadata.get("tier_1_sensors", [])),
                    len(raw.dag_metadata.get("tier_2_sensors", [])),
                ],
            },
        )
    except Exception as e:
        logger.warning("score_chain_record_failed", error=str(e))

    total_time = round((time.time() - start) * 1000, 2)
    logger.info("entity_observed",
                target=target,
                score=score_result.score,
                grade=score_result.grade.value,
                sources=f"{len(raw.sources_responded)}/{len(raw.sources_queried)}",
                infra_fingerprint=raw.infra_fingerprint_hash[:12] if raw.infra_fingerprint_hash else "none",
                vt_gated=raw.dag_metadata.get("vt_gated", False),
                total_time_ms=total_time)

    return raw


async def observe_entity_flat(target: str) -> RawSignals:
    """
    Legacy flat observation (no DAG, no InfraDNA).
    Kept for backward compatibility and A/B testing.
    Fires all sensors in parallel via asyncio.gather(*).
    """
    from app.compute.collectors_v3 import collect_all_signals
    return await collect_all_signals(target)
