"""
Tests for the DAG enrichment pipeline and Infrastructure DNA fingerprinting.
"""
import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.trust.engine_v3 import (
    RawSignals, compute_score, TrustGrade, Recommendation,
    score_existence_and_age, score_security_and_integrity,
    score_reputation_and_scale, score_operational_maturity,
    apply_hard_caps,
)
from app.compute.infra_dna import (
    _normalize_server, _extract_server_version, _match_signatures,
    compute_fingerprint_hash, CDN_SIGNATURES, WAF_SIGNATURES,
    TECH_STACK_HEADERS, merge_http_and_infra,
)
from app.compute.dag import DAGContext, should_query_virustotal, should_probe_web_presence


def test_server_normalization():
    """Test server header parsing."""
    assert _normalize_server("nginx/1.25.3 (Ubuntu)") == "nginx"
    assert _normalize_server("Apache/2.4.57 (Debian)") == "apache"
    assert _normalize_server("cloudflare") == "cloudflare"
    assert _normalize_server("Microsoft-IIS/10.0") == "microsoft-iis"
    assert _normalize_server("") == ""
    assert _normalize_server("envoy") == "envoy"
    print("  ✓ Server normalization")


def test_server_version_extraction():
    """Test version extraction from Server header."""
    assert _extract_server_version("nginx/1.25.3") == "1.25.3"
    assert _extract_server_version("Apache/2.4.57") == "2.4.57"
    assert _extract_server_version("cloudflare") == ""
    assert _extract_server_version("Microsoft-IIS/10.0") == "10.0"
    print("  ✓ Server version extraction")


def test_cdn_signature_matching():
    """Test CDN detection from headers."""
    # Cloudflare
    headers = {"server": "cloudflare", "cf-ray": "abc123", "cf-cache-status": "HIT"}
    matches = _match_signatures(headers, CDN_SIGNATURES)
    assert "cloudflare" in matches
    print("  ✓ Cloudflare CDN detection")

    # Vercel
    headers = {"x-vercel-id": "iad1::abc", "server": "vercel"}
    matches = _match_signatures(headers, CDN_SIGNATURES)
    assert "vercel" in matches
    print("  ✓ Vercel CDN detection")

    # No CDN
    headers = {"server": "nginx/1.25", "content-type": "text/html"}
    matches = _match_signatures(headers, CDN_SIGNATURES)
    assert len(matches) == 0
    print("  ✓ No CDN correctly detected")


def test_waf_detection():
    """Test WAF signature matching."""
    headers = {"cf-ray": "abc", "server": "cloudflare"}
    matches = _match_signatures(headers, WAF_SIGNATURES)
    assert "cloudflare_waf" in matches
    print("  ✓ Cloudflare WAF detection")

    headers = {"x-sucuri-id": "123", "x-sucuri-cache": "HIT"}
    matches = _match_signatures(headers, WAF_SIGNATURES)
    assert "sucuri_waf" in matches
    print("  ✓ Sucuri WAF detection")


def test_tech_stack_detection():
    """Test tech stack fingerprinting."""
    headers = {"server": "nginx", "x-powered-by": "express"}
    matches = _match_signatures(headers, TECH_STACK_HEADERS)
    assert "nginx" in matches
    assert "express" in matches
    print("  ✓ Tech stack detection (nginx + express)")

    headers = {"x-shopify-stage": "production", "x-shopid": "123"}
    matches = _match_signatures(headers, TECH_STACK_HEADERS)
    assert "shopify" in matches
    print("  ✓ Shopify platform detection")


def test_fingerprint_hash_determinism():
    """Test that same infra produces same hash."""
    h1 = compute_fingerprint_hash("nginx", "cloudflare", "cloudflare_waf", ["nginx", "express"])
    h2 = compute_fingerprint_hash("nginx", "cloudflare", "cloudflare_waf", ["nginx", "express"])
    assert h1 == h2
    print("  ✓ Fingerprint hash is deterministic")

    h3 = compute_fingerprint_hash("apache", "cloudflare", "cloudflare_waf", ["nginx", "express"])
    assert h1 != h3
    print("  ✓ Different infra produces different hash")

    # Order of tech stack should not matter (sorted internally)
    h4 = compute_fingerprint_hash("nginx", "cloudflare", "cloudflare_waf", ["express", "nginx"])
    assert h1 == h4
    print("  ✓ Tech stack order doesn't affect hash")


def test_dag_context_best_entity_name():
    """Test entity name resolution priority."""
    ctx = DAGContext(name="Stripe", whois_org="Stripe, Inc.", ssl_org="Stripe Inc")
    assert ctx.best_entity_name() == "Stripe, Inc."
    print("  ✓ WHOIS org name has priority")

    ctx = DAGContext(name="Stripe", whois_org="", ssl_org="Stripe Inc")
    assert ctx.best_entity_name() == "Stripe Inc"
    print("  ✓ SSL org used as fallback")

    ctx = DAGContext(name="Stripe", whois_org="", ssl_org="")
    assert ctx.best_entity_name() == "Stripe"
    print("  ✓ Parsed name used as last resort")


def test_vt_gate():
    """Test VirusTotal gating logic."""
    # Good domain — should query
    ctx = DAGContext(domain="stripe.com", domain_age_days=5000, tranco_rank=100, ssl_valid=True)
    assert should_query_virustotal(ctx) is True
    print("  ✓ VT gate: allows established domains")

    # No domain — should not query
    ctx = DAGContext(domain="", domain_age_days=0, tranco_rank=0, ssl_valid=False)
    assert should_query_virustotal(ctx) is False
    assert ctx.vt_gate_reason == "no_domain"
    print("  ✓ VT gate: blocks no-domain targets")

    # Brand new disposable domain — should not query
    ctx = DAGContext(domain="xyz123abc.com", domain_age_days=3, tranco_rank=0, ssl_valid=False)
    assert should_query_virustotal(ctx) is False
    assert ctx.vt_gate_reason == "disposable_domain_signal"
    print("  ✓ VT gate: blocks disposable domains")


def test_web_presence_gate():
    """Test web presence gating logic."""
    # Site returns 200 — should probe
    ctx = DAGContext(http_status=200, site_reachable=True, dns_reachable=True)
    assert should_probe_web_presence(ctx) is True
    print("  ✓ Web presence gate: allows reachable sites")

    # Site returns 503 — should skip
    ctx = DAGContext(http_status=503, site_reachable=False, dns_reachable=True)
    assert should_probe_web_presence(ctx) is False
    assert "server_error" in ctx.web_presence_skip_reason
    print("  ✓ Web presence gate: skips 5xx errors")

    # Site completely unreachable
    ctx = DAGContext(http_status=0, site_reachable=False, dns_reachable=False)
    assert should_probe_web_presence(ctx) is False
    assert "unreachable" in ctx.web_presence_skip_reason
    print("  ✓ Web presence gate: skips unreachable sites")


def test_infra_dna_scoring():
    """Test that Infrastructure DNA signals affect scoring."""
    # Enterprise signals: WAF + CDN + fast response
    enterprise = RawSignals(
        target="stripe.com",
        infra_has_waf=True,
        infra_has_cdn=True,
        infra_response_time_ms=150.0,
        infra_tech_stack=["nginx", "express", "varnish"],
        infra_is_saas_platform=False,
        infra_is_shared_hosting=False,
    )

    # Budget signals: no WAF, no CDN, slow, shared hosting
    budget = RawSignals(
        target="sketchy-deals.xyz",
        infra_has_waf=False,
        infra_has_cdn=False,
        infra_response_time_ms=4000.0,
        infra_tech_stack=[],
        infra_is_saas_platform=False,
        infra_is_shared_hosting=True,
    )

    si_ent, si_ent_bd = score_security_and_integrity(enterprise)
    si_bud, si_bud_bd = score_security_and_integrity(budget)
    assert si_ent > si_bud, f"Enterprise SI ({si_ent}) should beat budget ({si_bud})"
    assert "waf_detected" in si_ent_bd
    assert "cdn_detected" in si_ent_bd
    print(f"  ✓ Enterprise SI ({si_ent}) > Budget SI ({si_bud})")

    om_ent, om_ent_bd = score_operational_maturity(enterprise)
    om_bud, om_bud_bd = score_operational_maturity(budget)
    assert om_ent > om_bud, f"Enterprise OM ({om_ent}) should beat budget ({om_bud})"
    assert "fast_response" in om_ent_bd
    assert "tech_stack_depth" in om_ent_bd
    assert "shared_hosting_penalty" in om_bud_bd
    assert "slow_response_penalty" in om_bud_bd
    print(f"  ✓ Enterprise OM ({om_ent}) > Budget OM ({om_bud})")


def test_full_score_with_infra():
    """Test end-to-end scoring with InfraDNA signals."""
    signals = RawSignals(
        target="stripe.com",
        # Existence
        domain_age_days=5000,
        ssl_valid=True,
        ssl_cert_type="EV",
        first_cert_days_ago=3000,
        has_wikipedia=True,
        has_wikidata=True,
        whois_org="Stripe, Inc.",
        ssl_org="Stripe, Inc.",
        domain_expiry_years_ahead=5.0,
        # Security
        dns_has_spf=True,
        dns_has_dmarc=True,
        dns_has_dkim=True,
        dns_has_dnssec=True,
        http_has_hsts=True,
        http_has_csp=True,
        http_has_xframe=True,
        http_has_xcontent_type=True,
        http_has_referrer_policy=True,
        http_has_permissions_policy=True,
        vt_queried=True,
        vt_malicious_count=0,
        # InfraDNA
        infra_has_waf=True,
        infra_has_cdn=True,
        infra_response_time_ms=120.0,
        infra_tech_stack=["nginx", "varnish"],
        infra_server="nginx",
        infra_cdn="cloudflare",
        infra_waf="cloudflare_waf",
        infra_fingerprint_hash="abc123",
        # Reputation
        tranco_rank=50,
        social_twitter=True,
        social_linkedin=True,
        social_github=True,
        social_count=5,
        # Operational
        has_structured_data=True,
        has_org_schema=True,
        has_status_page=True,
        has_api_docs=True,
        has_changelog=True,
        has_security_txt=True,
        has_robots_txt=True,
        dns_has_mx=True,
        total_certs_issued=20,
        # Sources
        sources_queried=["tranco", "crtsh", "vt", "dns", "http", "whois", "kg", "web", "social"],
        sources_responded=["tranco", "crtsh", "vt", "dns", "http", "whois", "kg", "web", "social"],
    )

    result = compute_score(signals)

    print(f"  Score: {result.score}/1000")
    print(f"  Grade: {result.grade.value}")
    print(f"  Recommendation: {result.recommendation.value}")
    print(f"  Confidence: {result.confidence:.2f} ({result.confidence_label})")
    print(f"  EA: {result.existence_age}, SI: {result.security_integrity}, "
          f"RS: {result.reputation_scale}, OM: {result.operational_maturity}")
    print(f"  InfraDNA: server={result.infra_dna.get('server')}, "
          f"cdn={result.infra_dna.get('cdn')}, waf={result.infra_dna.get('waf')}")

    assert result.score >= 800, f"Expected high score, got {result.score}"
    assert result.grade in (TrustGrade.AAA, TrustGrade.AA)
    assert result.recommendation == Recommendation.PROCEED
    assert result.infra_dna.get("server") == "nginx"
    assert result.infra_dna.get("cdn") == "cloudflare"
    assert result.infra_dna.get("has_waf") is True
    assert result.infra_dna.get("fingerprint_hash") == "abc123"
    print(f"  ✓ Full score: {result.score} ({result.grade.value})")


def test_merge_http_and_infra():
    """Test merging of HTTP and InfraDNA signals."""
    http = {"http_has_hsts": True, "http_status": 200}
    infra = {"infra_server": "nginx", "infra_has_cdn": True}
    merged = merge_http_and_infra(http, infra)
    assert merged["http_has_hsts"] is True
    assert merged["infra_server"] == "nginx"
    assert merged["infra_has_cdn"] is True
    assert merged["http_status"] == 200
    print("  ✓ HTTP + InfraDNA merge")


def test_raw_signals_new_fields():
    """Test that RawSignals has all new fields with defaults."""
    raw = RawSignals(target="test.com")
    assert raw.infra_server == ""
    assert raw.infra_cdn == ""
    assert raw.infra_waf == ""
    assert raw.infra_tech_stack == []
    assert raw.infra_response_time_ms == 0.0
    assert raw.infra_has_waf is False
    assert raw.infra_has_cdn is False
    assert raw.infra_fingerprint_hash == ""
    assert raw.infra_is_saas_platform is False
    assert raw.infra_is_shared_hosting is False
    assert raw.dag_metadata == {}
    print("  ✓ RawSignals new fields initialized correctly")


if __name__ == "__main__":
    print("\n═══ Market2Agent — DAG Pipeline & InfraDNA Tests ═══\n")

    print("▸ Infrastructure DNA")
    test_server_normalization()
    test_server_version_extraction()
    test_cdn_signature_matching()
    test_waf_detection()
    test_tech_stack_detection()
    test_fingerprint_hash_determinism()
    test_merge_http_and_infra()

    print("\n▸ DAG Pipeline Gates")
    test_dag_context_best_entity_name()
    test_vt_gate()
    test_web_presence_gate()

    print("\n▸ Scoring Integration")
    test_raw_signals_new_fields()
    test_infra_dna_scoring()
    test_full_score_with_infra()

    print("\n═══ All tests passed ═══\n")
