"""
Market2Agent — DAG Enrichment Pipeline
Dependency-ordered data collection.

Instead of firing all 9 sensors in a flat asyncio.gather(*),
we execute in dependency tiers so that early results INFORM later collectors.

    ┌─────────────────────────────────────────────────────────────────┐
    │                    TIER 0 — Foundation                          │
    │  Tranco (Redis, <1ms)  │  DNS  │  WHOIS  │  crt.sh            │
    │  No dependencies. Fire immediately.                             │
    └──────────────┬──────────────────────────────────────────────────┘
                   │ Results feed Tier 1
    ┌──────────────▼──────────────────────────────────────────────────┐
    │                    TIER 1 — Enriched                            │
    │  HTTP + InfraDNA         │  VirusTotal (gated on domain)       │
    │  Uses: DNS reachability, crt.sh cert type                      │
    │  VT gated: skip if no domain OR Tranco > 900K & no SSL        │
    └──────────────┬──────────────────────────────────────────────────┘
                   │ Results feed Tier 2
    ┌──────────────▼──────────────────────────────────────────────────┐
    │                    TIER 2 — Context                             │
    │  Knowledge Graph  │  Web Presence  │  Social                   │
    │  Uses: WHOIS org name for better entity resolution             │
    │  Web Presence: skips if HTTP returned 5xx / unreachable        │
    │  Social: uses resolved entity name from KG/WHOIS               │
    └─────────────────────────────────────────────────────────────────┘

The DAG saves:
  - API calls (skip VT for garbage domains)
  - Time (don't probe dead sites for structured data)
  - Accuracy (knowledge graph search uses WHOIS org name, not guessed name)
"""
import asyncio
import time
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Tuple

import httpx
import structlog

from app.compute.collectors_v3 import (
    parse_target,
    collect_tranco,
    collect_crtsh,
    collect_virustotal,
    collect_dns,
    collect_http_headers,
    collect_whois,
    collect_knowledge_graph,
    collect_web_presence,
    collect_social,
)
from app.compute.infra_dna import collect_infra_dna, merge_http_and_infra
from app.chain.trustchain import record_observation, Sensor
from app.trust.engine_v3 import RawSignals

logger = structlog.get_logger()

_TIMEOUT = httpx.Timeout(10.0, connect=5.0)


@dataclass
class TierResult:
    """Holds results from a single DAG tier."""
    name: str
    data: Dict[str, Any] = field(default_factory=dict)
    elapsed_ms: float = 0.0
    success: bool = True
    error: str = ""


@dataclass
class DAGContext:
    """
    Accumulated context from prior tiers.
    Each tier reads from this and writes to it.
    This is the "wire" that makes the DAG a DAG instead of a flat list.
    """
    # Identity (from Tier 0)
    domain: str = ""
    name: str = ""
    raw_target: str = ""

    # Tier 0 outputs
    tranco_rank: int = 0
    dns_reachable: bool = False
    dns_has_mx: bool = False
    whois_org: str = ""
    whois_registrar: str = ""
    domain_age_days: int = 0
    ssl_valid: bool = False
    ssl_cert_type: str = ""
    ssl_org: str = ""

    # Tier 1 outputs
    http_status: int = 0
    site_reachable: bool = False
    resolved_org_name: str = ""  # Best-effort org name from WHOIS/SSL/crt.sh

    # Gate decisions (for observability)
    vt_gated: bool = False
    vt_gate_reason: str = ""
    web_presence_skipped: bool = False
    web_presence_skip_reason: str = ""

    def best_entity_name(self) -> str:
        """Return the best entity name we have, in priority order."""
        if self.whois_org and len(self.whois_org) > 2 and self.whois_org.lower() != "none":
            return self.whois_org
        if self.ssl_org and len(self.ssl_org) > 2:
            return self.ssl_org
        if self.resolved_org_name:
            return self.resolved_org_name
        return self.name


# ── Tier Executors ────────────────────────────────

async def _run_tier(
    tasks: Dict[str, Any],
    entity_id: str,
    tier_name: str,
) -> Dict[str, TierResult]:
    """
    Execute all tasks in a tier in parallel.
    Records each result to the TrustChain.
    Returns {sensor_name: TierResult}.
    """
    keys = list(tasks.keys())
    coros = list(tasks.values())

    results = {}
    gathered = await asyncio.gather(
        *[_timed(k, c) for k, c in zip(keys, coros)],
        return_exceptions=True,
    )

    for i, res in enumerate(gathered):
        sensor_key = keys[i]
        if isinstance(res, tuple):
            name, data, elapsed = res
            results[sensor_key] = TierResult(
                name=name, data=data, elapsed_ms=elapsed, success=True
            )
            # Record to chain
            try:
                record_observation(
                    entity_id=entity_id,
                    sensor=sensor_key,
                    signals=data,
                    collection_time_ms=elapsed,
                )
            except Exception as e:
                logger.warning("chain_record_failed", sensor=sensor_key, error=str(e))
        elif isinstance(res, Exception):
            results[sensor_key] = TierResult(
                name=sensor_key, success=False, error=str(res)[:200]
            )
        else:
            results[sensor_key] = TierResult(
                name=sensor_key, success=False, error="unexpected_result_type"
            )

    logger.debug("tier_complete", tier=tier_name,
                 sensors=list(results.keys()),
                 successes=sum(1 for r in results.values() if r.success))
    return results


async def _timed(name: str, coro):
    """Run a coroutine with timing."""
    t0 = time.time()
    try:
        result = await asyncio.wait_for(coro, timeout=15.0)
        return name, result, round((time.time() - t0) * 1000, 2)
    except Exception as e:
        logger.debug("sensor_timeout_or_error", name=name, error=str(e))
        return name, {}, round((time.time() - t0) * 1000, 2)


# ── Gate Functions ────────────────────────────────

def should_query_virustotal(ctx: DAGContext) -> bool:
    """
    Gate: Should we spend a VT API call on this target?
    VT is rate-limited (4 req/min on free tier). Don't waste it.
    """
    # No domain → can't query VT
    if not ctx.domain:
        ctx.vt_gated = True
        ctx.vt_gate_reason = "no_domain"
        return False

    # Known garbage: very new domain, no Tranco rank, no SSL
    if (ctx.domain_age_days > 0 and ctx.domain_age_days < 7
            and ctx.tranco_rank == 0 and not ctx.ssl_valid):
        ctx.vt_gated = True
        ctx.vt_gate_reason = "disposable_domain_signal"
        return False

    return True


def should_probe_web_presence(ctx: DAGContext) -> bool:
    """
    Gate: Should we crawl the site for structured data?
    If the site returned 5xx or is unreachable, don't bother.
    """
    if ctx.http_status >= 500:
        ctx.web_presence_skipped = True
        ctx.web_presence_skip_reason = f"server_error_{ctx.http_status}"
        return False

    if not ctx.site_reachable and not ctx.dns_reachable:
        ctx.web_presence_skipped = True
        ctx.web_presence_skip_reason = "site_unreachable"
        return False

    return True


# ── Main DAG Pipeline ────────────────────────────

async def run_dag(target: str) -> Tuple[RawSignals, DAGContext]:
    """
    Execute the full DAG enrichment pipeline.
    Returns (RawSignals for scoring, DAGContext for observability).

    This replaces the flat collect_all_signals() with dependency-aware
    tier execution.
    """
    pipeline_start = time.time()
    parsed = parse_target(target)
    domain = parsed["domain"]
    name = parsed["name"]
    entity_id = domain or target.lower().strip()

    ctx = DAGContext(domain=domain, name=name, raw_target=target)
    raw = RawSignals(target=target)
    raw.sources_queried = []
    raw.sources_responded = []

    async with httpx.AsyncClient(
        headers={"User-Agent": "Market2Agent Sensor/4.1 (+https://market2agent.ai/bot)"},
        follow_redirects=True,
        verify=True,
        timeout=_TIMEOUT,
    ) as client:

        # ════════════════════════════════════════════
        # TIER 0 — Foundation (no dependencies)
        # ════════════════════════════════════════════
        tier0_tasks = {}
        if domain:
            tier0_tasks[Sensor.TRANCO.value] = collect_tranco(domain)
            tier0_tasks[Sensor.DNS.value] = collect_dns(domain)
            tier0_tasks[Sensor.WHOIS.value] = collect_whois(domain)
            tier0_tasks[Sensor.CRTSH.value] = collect_crtsh(domain, client)

        raw.sources_queried.extend(tier0_tasks.keys())
        tier0 = await _run_tier(tier0_tasks, entity_id, "tier_0") if tier0_tasks else {}

        # Extract Tier 0 context for downstream gates
        _extract_tier0_context(ctx, tier0)

        # ════════════════════════════════════════════
        # TIER 1 — Enriched (uses Tier 0 context)
        # ════════════════════════════════════════════
        tier1_tasks = {}
        if domain:
            # HTTP + Infrastructure DNA — always run if we have a domain
            tier1_tasks[Sensor.HTTP_HEADERS.value] = _collect_http_with_infra(
                domain, client, ctx
            )

            # VirusTotal — GATED
            if should_query_virustotal(ctx):
                tier1_tasks[Sensor.VIRUSTOTAL.value] = collect_virustotal(domain, client)
            else:
                logger.debug("vt_gated", domain=domain, reason=ctx.vt_gate_reason)

        raw.sources_queried.extend(tier1_tasks.keys())
        tier1 = await _run_tier(tier1_tasks, entity_id, "tier_1") if tier1_tasks else {}

        # Extract Tier 1 context
        _extract_tier1_context(ctx, tier1)

        # ════════════════════════════════════════════
        # TIER 2 — Context (uses Tier 0+1 context)
        # ════════════════════════════════════════════
        tier2_tasks = {}

        # Knowledge graph — use best entity name (from WHOIS/SSL, not just guessed)
        kg_name = ctx.best_entity_name()
        tier2_tasks[Sensor.KNOWLEDGE_GRAPH.value] = collect_knowledge_graph(
            kg_name, domain, client
        )

        # Web presence — GATED on site reachability
        if domain and should_probe_web_presence(ctx):
            tier2_tasks[Sensor.WEB_PRESENCE.value] = collect_web_presence(domain, client)
        elif ctx.web_presence_skipped:
            logger.debug("web_presence_skipped", domain=domain,
                         reason=ctx.web_presence_skip_reason)

        # Social — use best entity name
        social_name = ctx.best_entity_name()
        tier2_tasks[Sensor.SOCIAL.value] = collect_social(social_name, domain, client)

        raw.sources_queried.extend(tier2_tasks.keys())
        tier2 = await _run_tier(tier2_tasks, entity_id, "tier_2") if tier2_tasks else {}

    # ════════════════════════════════════════════
    # MERGE — All tiers → RawSignals
    # ════════════════════════════════════════════
    all_results = {**tier0, **tier1, **tier2}

    for sensor_name, tier_result in all_results.items():
        if tier_result.success and tier_result.data:
            raw.sources_responded.append(sensor_name)

    _map_to_raw_signals(raw, all_results)

    # DAG metadata
    raw.collection_time_ms = round((time.time() - pipeline_start) * 1000, 2)

    # Store DAG decisions in raw signals for observability
    raw.dag_metadata = {
        "vt_gated": ctx.vt_gated,
        "vt_gate_reason": ctx.vt_gate_reason,
        "web_presence_skipped": ctx.web_presence_skipped,
        "web_presence_skip_reason": ctx.web_presence_skip_reason,
        "resolved_entity_name": ctx.best_entity_name(),
        "tier_0_sensors": list(tier0.keys()),
        "tier_1_sensors": list(tier1.keys()),
        "tier_2_sensors": list(tier2.keys()),
    }

    return raw, ctx


# ── Combined HTTP + InfraDNA Collector ────────────

async def _collect_http_with_infra(
    domain: str,
    client: httpx.AsyncClient,
    ctx: DAGContext,
) -> Dict[str, Any]:
    """
    Run standard HTTP header check AND Infrastructure DNA fingerprinting
    in a single pass. Shares the HTTP response to avoid double-fetching.
    """
    # Standard headers
    http_signals = await collect_http_headers(domain, client)

    # Infrastructure DNA (uses same domain, may share response)
    infra_signals = await collect_infra_dna(domain, client, ctx.ssl_cert_type)

    # Merge: infra signals extend HTTP signals
    return merge_http_and_infra(http_signals, infra_signals)


# ── Context Extractors ────────────────────────────

def _extract_tier0_context(ctx: DAGContext, tier0: Dict[str, TierResult]):
    """Pull key facts from Tier 0 into DAGContext for downstream gates."""
    # Tranco
    tr = tier0.get(Sensor.TRANCO.value)
    if tr and tr.success:
        ctx.tranco_rank = tr.data.get("tranco_rank", 0)

    # DNS
    dns = tier0.get(Sensor.DNS.value)
    if dns and dns.success:
        ctx.dns_reachable = True  # If DNS resolved at all, domain exists
        ctx.dns_has_mx = dns.data.get("dns_has_mx", False)

    # WHOIS
    wh = tier0.get(Sensor.WHOIS.value)
    if wh and wh.success:
        ctx.whois_org = wh.data.get("whois_org", "")
        ctx.whois_registrar = wh.data.get("whois_registrar", "")
        ctx.domain_age_days = wh.data.get("domain_age_days", 0)

    # crt.sh
    ct = tier0.get(Sensor.CRTSH.value)
    if ct and ct.success:
        ctx.ssl_valid = ct.data.get("ssl_valid", False)
        ctx.ssl_cert_type = ct.data.get("ssl_cert_type", "")
        ctx.ssl_org = ct.data.get("ssl_org", "")


def _extract_tier1_context(ctx: DAGContext, tier1: Dict[str, TierResult]):
    """Pull key facts from Tier 1 into DAGContext."""
    http = tier1.get(Sensor.HTTP_HEADERS.value)
    if http and http.success:
        ctx.http_status = http.data.get("http_status", 0)
        ctx.site_reachable = 200 <= ctx.http_status < 500

        # Resolved org name from Infrastructure DNA
        infra_org = http.data.get("infra_org_name", "")
        if infra_org and len(infra_org) > 2:
            ctx.resolved_org_name = infra_org


# ── Raw Signal Mapping ────────────────────────────

def _map_to_raw_signals(raw: RawSignals, results: Dict[str, TierResult]):
    """Map all tier results into the flat RawSignals dataclass."""
    def _get(sensor: str, key: str, default=None):
        r = results.get(sensor)
        if r and r.success and r.data:
            return r.data.get(key, default)
        return default

    # Tranco
    raw.tranco_rank = _get(Sensor.TRANCO.value, "tranco_rank", 0)

    # crt.sh
    raw.ssl_valid = _get(Sensor.CRTSH.value, "ssl_valid", False)
    raw.ssl_cert_type = _get(Sensor.CRTSH.value, "ssl_cert_type", "")
    raw.ssl_org = _get(Sensor.CRTSH.value, "ssl_org", "")
    raw.first_cert_days_ago = _get(Sensor.CRTSH.value, "first_cert_days_ago", 0)
    raw.total_certs_issued = _get(Sensor.CRTSH.value, "total_certs_issued", 0)
    raw.cert_issuer = _get(Sensor.CRTSH.value, "cert_issuer", "")

    # VirusTotal
    raw.vt_malicious_count = _get(Sensor.VIRUSTOTAL.value, "vt_malicious_count", 0)
    raw.vt_suspicious_count = _get(Sensor.VIRUSTOTAL.value, "vt_suspicious_count", 0)
    raw.vt_clean_count = _get(Sensor.VIRUSTOTAL.value, "vt_clean_count", 0)
    raw.vt_community_score = _get(Sensor.VIRUSTOTAL.value, "vt_community_score", 0)
    raw.vt_categories = _get(Sensor.VIRUSTOTAL.value, "vt_categories", [])
    raw.vt_queried = _get(Sensor.VIRUSTOTAL.value, "vt_queried", False)

    # DNS
    raw.dns_has_spf = _get(Sensor.DNS.value, "dns_has_spf", False)
    raw.dns_has_dmarc = _get(Sensor.DNS.value, "dns_has_dmarc", False)
    raw.dns_has_dkim = _get(Sensor.DNS.value, "dns_has_dkim", False)
    raw.dns_has_dnssec = _get(Sensor.DNS.value, "dns_has_dnssec", False)
    raw.dns_has_mx = _get(Sensor.DNS.value, "dns_has_mx", False)

    # HTTP + InfraDNA (merged in Tier 1)
    raw.http_has_hsts = _get(Sensor.HTTP_HEADERS.value, "http_has_hsts", False)
    raw.http_has_csp = _get(Sensor.HTTP_HEADERS.value, "http_has_csp", False)
    raw.http_has_xframe = _get(Sensor.HTTP_HEADERS.value, "http_has_xframe", False)
    raw.http_has_xcontent_type = _get(Sensor.HTTP_HEADERS.value, "http_has_xcontent_type", False)
    raw.http_has_referrer_policy = _get(Sensor.HTTP_HEADERS.value, "http_has_referrer_policy", False)
    raw.http_has_permissions_policy = _get(Sensor.HTTP_HEADERS.value, "http_has_permissions_policy", False)
    raw.http_status = _get(Sensor.HTTP_HEADERS.value, "http_status", 0)
    raw.has_security_txt = _get(Sensor.HTTP_HEADERS.value, "has_security_txt", False)
    raw.has_robots_txt = _get(Sensor.HTTP_HEADERS.value, "has_robots_txt", False)

    # Infrastructure DNA signals
    raw.infra_server = _get(Sensor.HTTP_HEADERS.value, "infra_server", "")
    raw.infra_cdn = _get(Sensor.HTTP_HEADERS.value, "infra_cdn", "")
    raw.infra_waf = _get(Sensor.HTTP_HEADERS.value, "infra_waf", "")
    raw.infra_tech_stack = _get(Sensor.HTTP_HEADERS.value, "infra_tech_stack", [])
    raw.infra_response_time_ms = _get(Sensor.HTTP_HEADERS.value, "infra_response_time_ms", 0.0)
    raw.infra_has_waf = _get(Sensor.HTTP_HEADERS.value, "infra_has_waf", False)
    raw.infra_has_cdn = _get(Sensor.HTTP_HEADERS.value, "infra_has_cdn", False)
    raw.infra_fingerprint_hash = _get(Sensor.HTTP_HEADERS.value, "infra_fingerprint_hash", "")

    # WHOIS
    raw.domain_age_days = _get(Sensor.WHOIS.value, "domain_age_days", 0)
    raw.whois_org = _get(Sensor.WHOIS.value, "whois_org", "")
    raw.whois_registrar = _get(Sensor.WHOIS.value, "whois_registrar", "")
    raw.domain_expiry_years_ahead = _get(Sensor.WHOIS.value, "domain_expiry_years_ahead", 0.0)

    # Knowledge graph
    raw.has_wikipedia = _get(Sensor.KNOWLEDGE_GRAPH.value, "has_wikipedia", False)
    raw.has_wikidata = _get(Sensor.KNOWLEDGE_GRAPH.value, "has_wikidata", False)
    raw.has_crunchbase = _get(Sensor.KNOWLEDGE_GRAPH.value, "has_crunchbase", False)

    # Web presence
    raw.has_structured_data = _get(Sensor.WEB_PRESENCE.value, "has_structured_data", False)
    raw.has_org_schema = _get(Sensor.WEB_PRESENCE.value, "has_org_schema", False)
    raw.has_status_page = _get(Sensor.WEB_PRESENCE.value, "has_status_page", False)
    raw.has_api_docs = _get(Sensor.WEB_PRESENCE.value, "has_api_docs", False)
    raw.has_changelog = _get(Sensor.WEB_PRESENCE.value, "has_changelog", False)

    # Social
    raw.social_twitter = _get(Sensor.SOCIAL.value, "social_twitter", False)
    raw.social_linkedin = _get(Sensor.SOCIAL.value, "social_linkedin", False)
    raw.social_github = _get(Sensor.SOCIAL.value, "social_github", False)
    raw.social_facebook = _get(Sensor.SOCIAL.value, "social_facebook", False)
    raw.social_youtube = _get(Sensor.SOCIAL.value, "social_youtube", False)
    raw.social_instagram = _get(Sensor.SOCIAL.value, "social_instagram", False)
    raw.social_count = _get(Sensor.SOCIAL.value, "social_count", 0)
