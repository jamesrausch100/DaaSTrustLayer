"""
Market2Agent — The Trust Hook for the AI Economy
Open-source SDK. Paid scores.

    pip install market2agent

This is the open-source integration layer. It's free. MIT licensed.
Anyone can embed trust checks into their code in 3 lines.

The SCORES are the product. They come from Market2Agent's
9-sensor observation network, SHA-256 hash-chained on the TrustChain,
scored by a proprietary evidence-accumulation algorithm.

The business model:
    - The SDK is free — install it anywhere
    - The score is paid — every verify() call is metered
    - The data lake is the moat — TrustChain observations accumulate over time

Usage:

    # === 3-line integration ===
    from market2agent import trust
    result = trust("stripe.com")
    if result.is_safe:
        proceed()

    # === Decorator (FastAPI / Flask) ===
    @require_trust("stripe.com", min_score=600)
    def process_payment():
        ...

    # === Middleware ===
    app.add_middleware(TrustGate, min_score=500)

    # === Async (for AI agent frameworks) ===
    result = await trust_async("stripe.com")

Built by James Rausch. Scottsdale, AZ.
https://market2agent.ai
"""

__version__ = "3.0.0"
__author__ = "James Rausch"
__license__ = "MIT"

from market2agent.client import (
    TrustClient,
    AsyncTrustClient,
    TrustResult,
    CompareResult,
    UsageInfo,
    TrustCheckError,
    EntityNotFound,
    RateLimited,
    QuotaExceeded,
)
from market2agent.hook import trust, trust_async, require_trust, configure
from market2agent.middleware import TrustGate

__all__ = [
    # The hook (90% of users need only this)
    "trust",
    "trust_async",
    "require_trust",
    "configure",

    # Middleware
    "TrustGate",

    # Full client (power users)
    "TrustClient",
    "AsyncTrustClient",

    # Types
    "TrustResult",
    "CompareResult",
    "UsageInfo",

    # Errors
    "TrustCheckError",
    "EntityNotFound",
    "RateLimited",
    "QuotaExceeded",
]
