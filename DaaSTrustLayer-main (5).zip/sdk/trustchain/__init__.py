"""
TrustChain — The background check of the internet.

    pip install trustchain

You wouldn't let a stranger into your home.
Why would you let one into your systems?

    from trustchain import verify

    result = verify("stripe.com")
    if result.trusted:
        proceed()

TrustChain checks any entity on the internet — domains, APIs, services,
AI agents — against 9 independent sensors, scores them 0-1000, and gives
you a clear answer: trusted or not.

Every check is backed by cryptographic proof. Every observation is
SHA-256 hashed and chained. You can audit the full history of any entity
and verify nothing was tampered with.

    pip install trustchain

That's it. That's the integration.
"""

__version__ = "1.0.0"
__author__ = "James Rausch"
__license__ = "MIT"

from trustchain.core import (
    verify,
    verify_async,
    guard,
    configure,
    TrustResult,
    TrustClient,
    AsyncTrustClient,
    TrustGate,
    TrustCheckError,
    Untrusted,
    RateLimited,
)

from trustchain.federation import (
    TrustNode,
    SpokeResult,
)

__all__ = [
    # The essentials (95% of users need only these)
    "verify",
    "verify_async",
    "guard",
    "configure",

    # Types
    "TrustResult",

    # Federation (spoke-and-wheel)
    "TrustNode",
    "SpokeResult",

    # Power users
    "TrustClient",
    "AsyncTrustClient",
    "TrustGate",

    # Errors
    "TrustCheckError",
    "Untrusted",
    "RateLimited",
]
