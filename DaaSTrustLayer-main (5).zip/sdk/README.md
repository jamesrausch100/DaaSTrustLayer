# TrustChain

**The background check of the internet.**

You wouldn't let a stranger into your home. Why would you let one into your systems?

```python
from trustchain import verify

result = verify("stripe.com")
print(result.trusted)  # True
print(result.score)    # 875
print(result.grade)    # "AAA"
```

TrustChain checks any entity on the internet — domains, APIs, AI agents, businesses — against 9 independent sensors and gives you a clear answer: **trusted or not**.

Every check is backed by cryptographic proof. Every observation is SHA-256 hashed and chained. Tamper-proof by design.

## Install

```bash
pip install trustchain
```

## Quick Start

```bash
export TRUSTCHAIN_API_KEY=m2a_live_...
```

```python
from trustchain import verify

# Check any entity
result = verify("stripe.com")

if result.trusted:
    proceed()
elif result.risky:
    flag_for_review()
elif result.rejected:
    block()

# TrustResult is truthy when trusted:
if verify("stripe.com"):
    do_business()
```

Get your API key at [market2agent.ai](https://market2agent.ai).

## Integration Patterns

### AI Agents

Before your agent calls an external service:

```python
from trustchain import verify_async

async def call_external(url):
    if not await verify_async(url):
        raise Exception("Untrusted service")
    return await make_request(url)
```

### Decorator

Gate any function behind a trust check:

```python
from trustchain import guard

@guard("partner-api.com", min_score=600)
def sync_partner_data():
    # Only runs if partner-api.com scores 600+
    ...

@guard("vendor.io", min_score=400, on_fail="warn")
def fetch_catalog():
    # Logs warning if under 400, proceeds anyway
    ...
```

### Middleware (FastAPI / ASGI)

Trust-gate your entire app in one line:

```python
from fastapi import FastAPI
from trustchain import TrustGate

app = FastAPI()
app.add_middleware(TrustGate, min_score=500)
```

Untrusted origins get a 403. Trusted requests pass through.

### Batch

```python
from trustchain import TrustClient

client = TrustClient(api_key="m2a_live_...")
results = client.batch(["stripe.com", "shopify.com", "unknown.xyz"])

for r in results:
    print(f"{r.target}: {'✓' if r.trusted else '✗'} {r.score}")
```

### Chain Audit

Verify that an entity's observation history is cryptographically intact:

```python
client = TrustClient(api_key="m2a_live_...")
proof = client.audit("stripe.com")
assert proof["verified"]  # SHA-256 chain is unbroken
```

## What Gets Checked

Nine independent sensors collect evidence in parallel:

- **DNS Security** — SPF, DMARC, DKIM, DNSSEC, MX records
- **SSL/TLS** — Certificate transparency, cert type (DV/OV/EV), issuer, history
- **VirusTotal** — 70 security vendor consensus
- **HTTP Security** — HSTS, CSP, X-Frame-Options, security.txt
- **Infrastructure DNA** — Server, CDN, WAF, tech stack, response time
- **WHOIS** — Domain age, registrar, expiry
- **Knowledge Graph** — Wikipedia, Wikidata, Crunchbase
- **Web Presence** — Structured data, status page, API docs
- **Social** — Twitter, LinkedIn, GitHub, Facebook

## Scoring

| Grade | Score | Meaning |
|---|---|---|
| AAA | 900+ | Exceptional trust |
| AA | 800+ | Very high trust |
| A | 700+ | High trust |
| BBB | 600+ | Good trust |
| BB | 500+ | Adequate |
| B | 400+ | Below average |
| CCC | 200+ | Poor |
| D | <200 | Untrusted |

## TrustResult

```python
result = verify("stripe.com")

result.trusted      # bool — safe to proceed?
result.risky        # bool — needs review?
result.rejected     # bool — do not proceed
result.score        # int — 0-1000
result.grade        # str — AAA through D
result.reason       # str — one-line verdict
result.confidence   # float — data backing (0.0-1.0)

# TrustResult is truthy:
if verify("stripe.com"):
    proceed()

# Clean repr:
print(result)  # TrustResult(✓ stripe.com 875/1000 AAA)
```

## Environment Variables

| Variable | Description |
|---|---|
| `TRUSTCHAIN_API_KEY` | Your API key |
| `TRUSTCHAIN_MIN_SCORE` | Default min score for TrustGate middleware |
| `TRUSTCHAIN_CACHE_TTL` | Middleware cache TTL in seconds (default 3600) |

## Federation — Spoke & Wheel

Build your own trust layer on top of TrustChain without affecting the canonical score.

```python
from trustchain import TrustNode

node = TrustNode(name="bob-payments", region="ap-south-1")

@node.sensor("payment_reliability", weight=2.0)
def check_payments(target):
    rate = get_failure_rate(target)
    return {"score": int((1 - rate) * 100), "fail_rate": rate}

@node.sensor("local_latency")
def check_latency(target):
    ms = ping(target)
    return {"score": 100 if ms < 50 else 60, "latency_ms": ms}

result = node.verify("stripe.com")
result.canonical_score   # 875 (from Market2Agent, immutable)
result.local_score       # 900 (from your sensors)
result.blended_score     # 882 (70/30 weighted blend)
```

**Security model:**

- Canonical score is READ-ONLY. Your sensors never touch it.
- Local sensors can ADD caution (flag something canonical missed) but never REMOVE it. If canonical says REJECT, your local score of 950 doesn't override that.
- Every `verify()` call is an API call. Market2Agent observes your usage patterns — volume, diversity, consistency, anomaly rate.
- Honest usage at scale increases YOUR trust score on the canonical chain. You don't claim trust. You earn it by behavior.
- Bad actors get flagged: burst patterns, target concentration, collusion signals, score shopping.

## License

MIT — use it anywhere, no restrictions.

Built by [James Rausch](https://market2agent.ai) in Scottsdale, AZ.
