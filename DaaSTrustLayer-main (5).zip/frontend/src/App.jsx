import { useState, useEffect, useRef } from 'react'

const SENSORS = [
  'Querying Tranco Top 1M…',
  'Checking Certificate Transparency…',
  'Scanning VirusTotal (70 vendors)…',
  'Verifying DNS Security…',
  'Inspecting HTTP Headers…',
  'Pulling WHOIS Records…',
  'Searching Knowledge Graphs…',
  'Analyzing Web Presence…',
  'Mapping Social Graph…',
]

function gradeClass(score) {
  if (score >= 600) return 'grade-high'
  if (score >= 400) return 'grade-mid'
  return 'grade-low'
}

function scoreColor(score) {
  if (score >= 700) return '#2D8B4E'
  if (score >= 500) return '#C68A17'
  return '#C43E3E'
}

/* ═══════════════ SCORE RING ═══════════════ */

function ScoreRing({ score, grade }) {
  const R = 50, C = 2 * Math.PI * R
  const pct = score / 1000
  const offset = C * (1 - pct)

  return (
    <div className="score-ring-wrap">
      <svg className="score-ring" width="120" height="120" viewBox="0 0 120 120">
        <circle className="score-ring-bg" cx="60" cy="60" r={R} />
        <circle
          className="score-ring-fill"
          cx="60" cy="60" r={R}
          stroke={scoreColor(score)}
          strokeDasharray={C}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="score-number">
        <strong>{score}</strong>
        <small>{grade}</small>
      </div>
    </div>
  )
}

/* ═══════════════ NAV ═══════════════ */

function Nav() {
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', fn, { passive: true })
    return () => window.removeEventListener('scroll', fn)
  }, [])

  return (
    <nav className={`nav ${scrolled ? 'scrolled' : ''}`}>
      <a href="#" className="nav-logo">Market<span>2</span>Agent</a>
      <div className="nav-links">
        <a href="#how">How It Works</a>
        <a href="#pricing">Pricing</a>
        <a href="#careers">Careers</a>
        <a href="/docs">API Docs</a>
        <a href="#waitlist" className="nav-cta">Get API Key</a>
      </div>
    </nav>
  )
}

/* ═══════════════ HERO ═══════════════ */

function Hero() {
  const [target, setTarget] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [sensorIdx, setSensorIdx] = useState(0)
  const intervalRef = useRef(null)

  async function handleScore(e) {
    e.preventDefault()
    if (!target.trim() || loading) return

    setResult(null)
    setLoading(true)
    setSensorIdx(0)

    intervalRef.current = setInterval(() => {
      setSensorIdx(i => (i + 1) % SENSORS.length)
    }, 600)

    try {
      const resp = await fetch(`/v1/trust/preview?target=${encodeURIComponent(target.trim())}`)
      const data = await resp.json()
      clearInterval(intervalRef.current)
      setResult(data)
    } catch {
      clearInterval(intervalRef.current)
      setResult({ error: true })
    } finally {
      setLoading(false)
    }
  }

  return (
    <section className="hero" id="top">
      <h1>The background check of&nbsp;the&nbsp;internet</h1>
      <p className="hero-sub">
        Score any entity — domains, APIs, AI agents, businesses —
        against 9 independent sensors. One call. One number. Cryptographic proof.
      </p>

      <div className="demo-box">
        <form onSubmit={handleScore}>
          <div className="demo-input-row">
            <input
              className="demo-input"
              type="text"
              placeholder="Enter any domain… stripe.com"
              value={target}
              onChange={e => setTarget(e.target.value)}
              autoFocus
            />
            <button className="demo-btn" type="submit" disabled={loading}>
              {loading ? 'Scanning…' : 'Score'}
            </button>
          </div>
        </form>

        {loading && (
          <div className="loading-state">
            <div className="loading-sensor">{SENSORS[sensorIdx]}</div>
          </div>
        )}

        {result && !result.error && (
          <div className="score-result">
            <ScoreRing score={result.score || 0} grade={result.grade || 'D'} />
            <div className="score-details">
              <span className={`score-grade ${gradeClass(result.score || 0)}`}>
                {result.grade}
              </span>
              <div className="score-rec">
                {result.recommendation?.replace(/_/g, ' ')}
              </div>
              <div className="score-sensors">
                {result.sources_used || 9} sensors · {result.confidence
                  ? `${Math.round(result.confidence * 100)}% confidence`
                  : 'SHA-256 chained'}
              </div>
            </div>
          </div>
        )}

        {result?.error && (
          <div className="loading-state">
            <div style={{ color: '#C43E3E', fontSize: 14 }}>
              Could not reach scoring API. Is the backend running?
            </div>
          </div>
        )}
      </div>
    </section>
  )
}

/* ═══════════════ PROOF BAR ═══════════════ */

function ProofBar() {
  return (
    <div className="proof-bar">
      <div className="proof-item"><strong>9</strong> independent sensors</div>
      <div className="proof-item"><strong>SHA-256</strong> hash-chained</div>
      <div className="proof-item"><strong>70</strong> security vendor consensus</div>
      <div className="proof-item"><strong>0→1000</strong> universal score</div>
    </div>
  )
}

/* ═══════════════ HOW IT WORKS ═══════════════ */

function HowItWorks() {
  return (
    <section id="how">
      <div className="section-label">How It Works</div>
      <h2 className="section-title">Three steps to trust</h2>
      <p className="section-sub">
        No signup required. Type a domain above and see the result in seconds.
      </p>

      <div className="how-grid">
        <div className="how-card">
          <div className="how-step">1</div>
          <h3>Sensors collect</h3>
          <p>
            Nine independent sensors fire in parallel — DNS records,
            SSL certificates, VirusTotal, WHOIS, knowledge graphs,
            web presence, social graph, HTTP security headers, and
            Tranco ranking. Every observation is recorded.
          </p>
        </div>
        <div className="how-card">
          <div className="how-step">2</div>
          <h3>Chain records</h3>
          <p>
            Every observation is SHA-256 hashed and linked to the
            previous block on the TrustChain — an append-only,
            cryptographically verifiable ledger. Nothing can be
            tampered with after the fact.
          </p>
        </div>
        <div className="how-card">
          <div className="how-step">3</div>
          <h3>Score computes</h3>
          <p>
            Evidence accumulates across four categories — existence,
            security, reputation, and maturity. The result is a single
            score from 0 to 1000 with a clear recommendation:
            proceed, review, or reject.
          </p>
        </div>
      </div>
    </section>
  )
}

/* ═══════════════ FIVE PILLARS ═══════════════ */

function Pillars() {
  const pillars = [
    { name: 'Existence', max: 300, desc: 'Domain age, SSL history, WHOIS, Wikipedia' },
    { name: 'Security', max: 300, desc: 'VirusTotal, DNS, HTTP headers, WAF/CDN' },
    { name: 'Reputation', max: 250, desc: 'Tranco rank, social, community trust' },
    { name: 'Maturity', max: 150, desc: 'Structured data, status page, tech stack' },
    { name: 'InfraDNA', max: '∞', desc: 'Server, CDN, WAF fingerprint, response time' },
  ]

  return (
    <section>
      <div className="section-label">Trust Architecture</div>
      <h2 className="section-title">Five pillars of trust</h2>
      <p className="section-sub">
        Every score is transparent. You see exactly which evidence contributed.
      </p>

      <div className="pillars-grid">
        {pillars.map(p => (
          <div className="pillar" key={p.name}>
            <div className="pillar-score">{p.max}</div>
            <div className="pillar-name">{p.name}</div>
            <div className="pillar-desc">{p.desc}</div>
          </div>
        ))}
      </div>
    </section>
  )
}

/* ═══════════════ PRICING ═══════════════ */

function Pricing() {
  return (
    <section id="pricing">
      <div className="section-label">Pricing</div>
      <h2 className="section-title">Start free. Scale when ready.</h2>
      <p className="section-sub">
        Preview scores are always free. No credit card required.
      </p>

      <div className="pricing-grid">
        <div className="price-card">
          <div className="price-name">Free</div>
          <div className="price-amount">$0</div>
          <div className="price-desc">Preview scores, forever free</div>
          <ul className="price-features">
            <li>Score + grade for any entity</li>
            <li>Rate limited (10/hr)</li>
            <li>No API key required</li>
            <li>Public preview endpoint</li>
          </ul>
          <a href="#top" className="price-btn">Try It Now</a>
        </div>

        <div className="price-card featured">
          <div className="price-name">Pro</div>
          <div className="price-amount">$50<span>/mo</span></div>
          <div className="price-desc">For developers shipping trust</div>
          <ul className="price-features">
            <li>1,000 scored calls/mo</li>
            <li>Full category breakdowns</li>
            <li>Infrastructure DNA</li>
            <li>TrustChain history</li>
            <li>pip install trustchain</li>
          </ul>
          <a href="#waitlist" className="price-btn primary">Get API Key</a>
        </div>

        <div className="price-card">
          <div className="price-name">Business</div>
          <div className="price-amount">$200<span>/mo</span></div>
          <div className="price-desc">For teams and platforms</div>
          <ul className="price-features">
            <li>10,000 scored calls/mo</li>
            <li>Batch scoring (25/call)</li>
            <li>Side-by-side comparison</li>
            <li>Score monitoring & alerts</li>
            <li>Priority support</li>
          </ul>
          <a href="#waitlist" className="price-btn">Contact Us</a>
        </div>
      </div>
    </section>
  )
}

/* ═══════════════ SDK ═══════════════ */

function SDK() {
  return (
    <section>
      <div className="section-label">Developer SDK</div>
      <h2 className="section-title">One line to trust</h2>
      <p className="section-sub">
        Install TrustChain, the open-source SDK. Every verify() call is backed
        by the Market2Agent scoring API.
      </p>

      <div className="demo-box" style={{ maxWidth: 600, fontFamily: "'Courier New', monospace" }}>
        <pre style={{ fontSize: 14, lineHeight: 1.8, color: '#3A3937', overflowX: 'auto' }}>
{`pip install trustchain

from trustchain import verify

result = verify("stripe.com")
print(result.score)    # 875
print(result.trusted)  # True
print(result.grade)    # "AAA"

# TrustResult is truthy:
if verify("stripe.com"):
    proceed()`}
        </pre>
      </div>
    </section>
  )
}

/* ═══════════════ CAREERS ═══════════════ */

function Careers() {
  return (
    <section id="careers">
      <div className="section-label">Careers</div>
      <h2 className="section-title">Build trust infrastructure</h2>

      <div className="careers-box">
        <div>
          <h3>Trust Scoring Engine Intern</h3>
          <p>
            We're hiring interns from ASU to help build the trust
            infrastructure layer for the AI economy. You'll work on
            real-time signal collection, scoring algorithms, and the
            TrustChain observation ledger. Chromebook and polo provided.
          </p>
          <p style={{ fontSize: 13, color: '#A8A6A1', marginBottom: 20 }}>
            Scottsdale, AZ · Internship · ASU students preferred
          </p>
          <a href="mailto:hello@market2agent.ai?subject=Trust Scoring Engine Intern" className="careers-email">
            Apply Now
          </a>
        </div>
      </div>
    </section>
  )
}

/* ═══════════════ WAITLIST ═══════════════ */

function Waitlist() {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    if (!email.trim() || submitting) return

    setSubmitting(true)
    try {
      await fetch('/v1/waitlist/join', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim() }),
      })
      setSubmitted(true)
    } catch {
      setSubmitted(true)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="waitlist-section" id="waitlist">
      <div className="section-label" style={{ color: '#B8963E' }}>Get Started</div>
      <h2 className="section-title">Score any entity on&nbsp;Earth</h2>
      <p className="section-sub">
        Join the waitlist for API access. Free preview is live right now.
      </p>

      {!submitted ? (
        <form onSubmit={handleSubmit}>
          <div className="waitlist-row">
            <input
              className="waitlist-input"
              type="email"
              placeholder="you@company.com"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
            />
            <button className="waitlist-btn" type="submit" disabled={submitting}>
              {submitting ? 'Joining…' : 'Join Waitlist'}
            </button>
          </div>
        </form>
      ) : (
        <div className="waitlist-success">
          You're on the list. We'll be in touch.
        </div>
      )}
    </div>
  )
}

/* ═══════════════ FOOTER ═══════════════ */

function Footer() {
  return (
    <footer className="footer">
      <p>
        © {new Date().getFullYear()} Market2Agent · Built by{' '}
        <a href="https://market2agent.ai">James Rausch</a> · Scottsdale, AZ
        {' · '}
        <a href="/docs">API Docs</a>
      </p>
    </footer>
  )
}

/* ═══════════════ APP ═══════════════ */

export default function App() {
  return (
    <>
      <Nav />
      <Hero />
      <ProofBar />
      <HowItWorks />
      <Pillars />
      <SDK />
      <Pricing />
      <Careers />
      <Waitlist />
      <Footer />
    </>
  )
}
